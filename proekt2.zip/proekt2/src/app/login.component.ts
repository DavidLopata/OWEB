import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  template: `<div>
    <h2>Login</h2>
    <input [(ngModel)]="username" placeholder="Username" />
    <input [(ngModel)]="password" type="password" placeholder="Password" />
    <button (click)="login()">Login</button>
  </div>`,
  styles: [`
    h2 { color: #ff6600; }
    input { display: block; margin-bottom: 10px; }
    button { background: #ff6600; color: white; border: none; padding: 5px 10px; }
  `]
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  login() {
    console.log(`Logging in with ${this.username} and ${this.password}`);
  }
}
