@Component({
    selector: 'app-used-audi',
    template: `<div>
      <h2>Used Audi Models</h2>
      <ul>
        <li *ngFor="let model of carModels">{{ model }}</li>
      </ul>
    </div>`,
    styles: [`ul { list-style-type: none; padding: 0; } li { background: #f4f4f4; margin: 5px 0; padding: 5px; }`]
  })
  export class UsedAudiComponent {
    carModels = ['Used Audi A3', 'Used Audi A5', 'Used Audi Q7'];
  }