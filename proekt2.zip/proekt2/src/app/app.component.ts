import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  template: `<div>
    <button (click)="currentView = 'login'">Login</button>
    <button (click)="currentView = 'newAudi'">New Audi</button>
    <button (click)="currentView = 'usedAudi'">Used Audi</button>
    
    <app-login *ngIf="currentView === 'login'"></app-login>
    <app-new-audi *ngIf="currentView === 'newAudi'"></app-new-audi>
    <app-used-audi *ngIf="currentView === 'usedAudi'"></app-used-audi>
  </div>`,
  styles: [`
    button { margin: 5px; padding: 5px 10px; background: #333; color: white; border: none; cursor: pointer; }
  `]
})
export class AppComponent {
  currentView: string = 'login';
}
